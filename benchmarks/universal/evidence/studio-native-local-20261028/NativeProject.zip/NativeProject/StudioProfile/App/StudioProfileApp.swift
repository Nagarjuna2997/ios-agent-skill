import SwiftUI

@main
struct StudioProfileApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
